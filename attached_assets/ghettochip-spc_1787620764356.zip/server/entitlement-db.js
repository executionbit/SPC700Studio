import fs from "node:fs";

/**
 * Minimal file-backed entitlement store keyed by Stripe customer id.
 *
 * This is intentionally simple so the payment flow can be tested end to
 * end without standing up a database. For production, replace this class
 * with one backed by Postgres/SQLite/etc — keep the same method surface
 * (grantPacks, getPacksForCustomer, revokeByChargeMetadata) so
 * server/index.js does not need to change.
 */
export class EntitlementDb {
  constructor(filePath) {
    this.filePath = filePath;
    this._load();
  }

  _load() {
    try {
      const raw = fs.readFileSync(this.filePath, "utf8");
      this.data = JSON.parse(raw);
    } catch {
      this.data = {};
    }
  }

  _save() {
    fs.writeFileSync(this.filePath, JSON.stringify(this.data, null, 2));
  }

  grantPacks(stripeCustomerId, packIds) {
    const existing = new Set(this.data[stripeCustomerId] ?? []);
    packIds.forEach((packId) => existing.add(packId));
    this.data[stripeCustomerId] = [...existing];
    this._save();
  }

  revokeByChargeMetadata(stripeCustomerId, packIdsCsv) {
    if (!stripeCustomerId || !packIdsCsv) return;
    const toRevoke = new Set(packIdsCsv.split(",").filter(Boolean));
    const remaining = (this.data[stripeCustomerId] ?? []).filter(
      (packId) => !toRevoke.has(packId)
    );
    this.data[stripeCustomerId] = remaining;
    this._save();
  }

  getPacksForCustomer(stripeCustomerId) {
    return this.data[stripeCustomerId] ?? [];
  }
}
