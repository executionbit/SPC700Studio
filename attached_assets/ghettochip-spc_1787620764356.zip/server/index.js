/**
 * Ghettochip Studio — DLC payment backend.
 *
 * Handles the parts of a Stripe integration that must never run in the
 * browser: creating Checkout Sessions with a secret key, verifying
 * webhook signatures, and recording which customer paid for which DLC
 * pack. The static frontend (deployed to GitHub Pages) talks to this
 * service over HTTPS — it is NOT part of the Vite build and must be
 * deployed separately (Render, Fly.io, Railway, a VPS, etc.) since
 * GitHub Pages cannot run server code.
 *
 * Setup:
 *   cd server && npm install
 *   cp .env.example .env   # fill in real values
 *   npm start
 *
 * Required env vars — see .env.example.
 */
import express from "express";
import cors from "cors";
import Stripe from "stripe";
import crypto from "node:crypto";
import { fileURLToPath } from "node:url";
import path from "node:path";
import fs from "node:fs";
import { DLC_CATALOG, getDlcPacks } from "../src/dlc/catalog.js";
import { EntitlementDb } from "./entitlement-db.js";

const __dirname = path.dirname(fileURLToPath(import.meta.url));

const {
  STRIPE_SECRET_KEY,
  STRIPE_WEBHOOK_SECRET,
  CLIENT_ORIGIN = "http://localhost:5173",
  ENTITLEMENT_DB_PATH = path.join(__dirname, "entitlements.json"),
  TOKEN_SIGNING_SECRET,
  PORT = 4242
} = process.env;

if (!STRIPE_SECRET_KEY) {
  console.error(
    "Missing STRIPE_SECRET_KEY. Copy server/.env.example to server/.env and fill it in."
  );
  process.exit(1);
}

if (!TOKEN_SIGNING_SECRET) {
  console.error(
    "Missing TOKEN_SIGNING_SECRET. Set it in server/.env (any long random string)."
  );
  process.exit(1);
}

const stripe = new Stripe(STRIPE_SECRET_KEY, { apiVersion: "2024-06-20" });
const db = new EntitlementDb(ENTITLEMENT_DB_PATH);

const app = express();
app.use(cors({ origin: CLIENT_ORIGIN }));

/**
 * Signs an opaque, non-guessable customer token that maps to a Stripe
 * customer id without exposing it directly to the browser.
 */
function issueCustomerToken(stripeCustomerId) {
  const payload = Buffer.from(JSON.stringify({ c: stripeCustomerId })).toString("base64url");
  const signature = crypto
    .createHmac("sha256", TOKEN_SIGNING_SECRET)
    .update(payload)
    .digest("base64url");
  return `${payload}.${signature}`;
}

function verifyCustomerToken(token) {
  if (!token || typeof token !== "string" || !token.includes(".")) return null;
  const [payload, signature] = token.split(".");
  const expected = crypto
    .createHmac("sha256", TOKEN_SIGNING_SECRET)
    .update(payload)
    .digest("base64url");
  if (!crypto.timingSafeEqual(Buffer.from(signature), Buffer.from(expected))) {
    return null;
  }
  try {
    const { c } = JSON.parse(Buffer.from(payload, "base64url").toString("utf8"));
    return c ?? null;
  } catch {
    return null;
  }
}

// --- Stripe webhook -------------------------------------------------------
// Must use the raw body for signature verification, so this route is
// registered BEFORE express.json() below.
app.post(
  "/api/webhook",
  express.raw({ type: "application/json" }),
  (request, response) => {
    let event;
    try {
      event = stripe.webhooks.constructEvent(
        request.body,
        request.headers["stripe-signature"],
        STRIPE_WEBHOOK_SECRET
      );
    } catch (error) {
      console.error("Webhook signature verification failed:", error.message);
      return response.status(400).send(`Webhook Error: ${error.message}`);
    }

    switch (event.type) {
      case "checkout.session.completed": {
        const session = event.data.object;
        const packIds = (session.metadata?.packIds ?? "").split(",").filter(Boolean);
        if (session.customer && packIds.length) {
          db.grantPacks(session.customer, packIds);
          console.log(`Granted ${packIds.join(", ")} to customer ${session.customer}`);
        }
        break;
      }
      // Handle disputes/refunds by revoking entitlement.
      case "charge.refunded":
      case "charge.dispute.created": {
        const charge = event.data.object;
        if (charge.customer) {
          db.revokeByChargeMetadata(charge.customer, charge.metadata?.packIds);
        }
        break;
      }
      default:
        break;
    }

    response.json({ received: true });
  }
);

app.use(express.json());

// --- Create a Checkout Session --------------------------------------------
app.post("/api/create-checkout-session", async (request, response) => {
  const { packIds, email, successUrl, cancelUrl } = request.body ?? {};

  if (!Array.isArray(packIds) || packIds.length === 0) {
    return response.status(400).json({ error: "packIds must be a non-empty array." });
  }

  const packs = getDlcPacks(packIds);
  if (packs.length !== packIds.length) {
    return response.status(400).json({ error: "One or more packIds are unknown." });
  }

  const missingPriceIds = packs.filter((pack) =>
    pack.stripePriceId.startsWith("price_REPLACE_ME_")
  );
  if (missingPriceIds.length) {
    return response.status(500).json({
      error: `Stripe Price IDs not configured for: ${missingPriceIds
        .map((pack) => pack.packId)
        .join(", ")}. Create prices in the Stripe Dashboard and update src/dlc/catalog.js.`
    });
  }

  try {
    const session = await stripe.checkout.sessions.create({
      mode: "payment",
      line_items: packs.map((pack) => ({
        price: pack.stripePriceId,
        quantity: 1
      })),
      customer_email: email || undefined,
      metadata: { packIds: packIds.join(",") },
      payment_intent_data: {
        metadata: { packIds: packIds.join(",") }
      },
      success_url: successUrl,
      cancel_url: cancelUrl
    });

    response.json({ url: session.url, sessionId: session.id });
  } catch (error) {
    console.error("Failed to create checkout session:", error);
    response.status(500).json({ error: "Could not create checkout session." });
  }
});

// --- Confirm a session after redirect back from Stripe ---------------------
app.get("/api/checkout-session/:sessionId", async (request, response) => {
  try {
    const session = await stripe.checkout.sessions.retrieve(request.params.sessionId);

    if (session.payment_status !== "paid") {
      return response.status(402).json({ error: "Payment not completed." });
    }

    const packIds = (session.metadata?.packIds ?? "").split(",").filter(Boolean);

    // Webhook is the source of truth for granting entitlement, but grant
    // here too in case the webhook hasn't landed yet (eventual consistency).
    if (session.customer && packIds.length) {
      db.grantPacks(session.customer, packIds);
    }

    response.json({
      customerToken: session.customer ? issueCustomerToken(session.customer) : null,
      packIds
    });
  } catch (error) {
    console.error("Failed to retrieve checkout session:", error);
    response.status(404).json({ error: "Session not found." });
  }
});

// --- Look up a customer's owned packs --------------------------------------
app.get("/api/entitlements", (request, response) => {
  const authHeader = request.headers.authorization ?? "";
  const token = authHeader.startsWith("Bearer ") ? authHeader.slice(7) : null;
  const stripeCustomerId = verifyCustomerToken(token);

  if (!stripeCustomerId) {
    return response.status(401).json({ error: "Invalid or missing customer token." });
  }

  response.json({ packIds: db.getPacksForCustomer(stripeCustomerId) });
});

// --- Public catalog (kept server-side too, so prices can't be tampered) ----
app.get("/api/catalog", (_request, response) => {
  response.json({
    packs: DLC_CATALOG.map(({ stripePriceId, ...publicFields }) => publicFields)
  });
});

app.listen(PORT, () => {
  console.log(`DLC payment backend listening on http://localhost:${PORT}`);
});
