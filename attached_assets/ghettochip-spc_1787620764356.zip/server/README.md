# DLC Payment Backend

A small Express service that does the parts of the Stripe integration that
must never run in the browser: creating Checkout Sessions with a secret
key, verifying webhook signatures, and recording which Stripe customer
paid for which DLC pack.

The main app (`../`) is a static Vite build meant for GitHub Pages, which
cannot run server code — so this backend is deployed **separately** (a
small VPS, Render, Fly.io, Railway, a container on any host that runs
Node). It talks to the frontend only over the small JSON API below.

## 1. Create Stripe Prices for each pack

For every entry in `../src/dlc/catalog.js`:

1. Stripe Dashboard → **Product catalog** → **Add product**.
2. Name it to match the pack (e.g. "Neon Arcade"), set the price from
   `priceUSD`, one-time payment.
3. Copy the resulting **Price ID** (`price_...`) and paste it into that
   pack's `stripePriceId` field in `catalog.js`, replacing the
   `price_REPLACE_ME_...` placeholder.

You can also script this with the Stripe CLI:

```bash
stripe products create --name "Neon Arcade" \
  | jq -r .id \
  | xargs -I{} stripe prices create --product {} --unit-amount 499 --currency usd
```

## 2. Configure environment variables

```bash
cd server
cp .env.example .env
```

Fill in:

- `STRIPE_SECRET_KEY` — from Dashboard → Developers → API keys. Use a
  `sk_test_...` key while developing.
- `STRIPE_WEBHOOK_SECRET` — from `stripe listen` (below) locally, or from
  the webhook endpoint you create in the Dashboard for production.
- `TOKEN_SIGNING_SECRET` — any long random string:
  `node -e "console.log(require('crypto').randomBytes(32).toString('hex'))"`
- `CLIENT_ORIGIN` — the origin your frontend is served from (CORS).

## 3. Install and run

```bash
npm install
npm start
```

In a second terminal, forward Stripe webhook events to your local server:

```bash
stripe listen --forward-to localhost:4242/api/webhook
```

(`npm run stripe:listen` runs the same command.) Copy the `whsec_...`
value it prints into `STRIPE_WEBHOOK_SECRET` in `.env` and restart the
server.

## 4. Point the frontend at the backend

In the repo root:

```bash
cp .env.example .env.local
# VITE_DLC_API_BASE_URL=http://localhost:4242
npm run dev
```

Open the app, scroll to **DLC SAMPLE PACKS**, and buy a pack using a
[Stripe test card](https://docs.stripe.com/testing) such as
`4242 4242 4242 4242` with any future expiry/CVC.

## API surface

| Endpoint | Method | Purpose |
| --- | --- | --- |
| `/api/catalog` | GET | Public pack list (no price IDs) |
| `/api/create-checkout-session` | POST | `{ packIds, email?, successUrl, cancelUrl }` → `{ url }` |
| `/api/checkout-session/:id` | GET | Confirms a completed session → `{ customerToken, packIds }` |
| `/api/entitlements` | GET | `Authorization: Bearer <customerToken>` → `{ packIds }` |
| `/api/webhook` | POST | Stripe webhook receiver (raw body, signature-verified) |

## Going to production

- Swap `EntitlementDb` (a flat JSON file) for a real database — the
  method surface (`grantPacks`, `getPacksForCustomer`,
  `revokeByChargeMetadata`) is deliberately small so this is a drop-in
  change.
- Register the production webhook URL in the Stripe Dashboard and use
  **live** keys (`sk_live_...`), never test keys, once you're ready to
  accept real payments.
- Put this service behind HTTPS (required for live Stripe webhooks).
- Consider replacing the HMAC customer token with real auth (magic-link
  email, OAuth) if you want entitlements to follow a user across devices
  rather than a single browser's localStorage.
