#!/usr/bin/env node
/**
 * Synthesizes short, original preview WAV files for every pack in
 * src/dlc/catalog.js. Every waveform here is generated from scratch with
 * basic oscillators (square/triangle/saw/noise) — nothing is sampled,
 * ripped, or derived from copyrighted game audio. These previews are
 * placeholders for the real BRR pack content referenced by
 * `sampleCount` in the catalog; swap them out with authored samples
 * before shipping.
 *
 * Usage: node scripts/generate-dlc-previews.mjs
 */
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { DLC_CATALOG } from "../src/dlc/catalog.js";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const OUT_DIR = path.join(__dirname, "..", "public", "dlc-previews");
const SAMPLE_RATE = 22050;

fs.mkdirSync(OUT_DIR, { recursive: true });

function square(t, freq) {
  return Math.sign(Math.sin(2 * Math.PI * freq * t));
}
function triangle(t, freq) {
  return (2 / Math.PI) * Math.asin(Math.sin(2 * Math.PI * freq * t));
}
function saw(t, freq) {
  const phase = (t * freq) % 1;
  return 2 * (phase - Math.floor(phase + 0.5));
}
function noise(seedRef) {
  // xorshift32 — deterministic, no Math.random() so output is reproducible.
  seedRef.value ^= seedRef.value << 13;
  seedRef.value ^= seedRef.value >>> 17;
  seedRef.value ^= seedRef.value << 5;
  seedRef.value >>>= 0;
  return (seedRef.value / 0xffffffff) * 2 - 1;
}

const WAVEFORM_BY_TAG = {
  lead: square,
  bass: triangle,
  pad: triangle,
  drone: triangle,
  fanfare: saw,
  drums: "noise",
  percussion: "noise",
  ui: square,
  sfx: square
};

function pickWaveform(pack) {
  for (const tag of pack.tags) {
    if (WAVEFORM_BY_TAG[tag]) return WAVEFORM_BY_TAG[tag];
  }
  return square;
}

// Deterministic base frequency per pack, derived from its packId so each
// preview is distinct without hand-tuning 12 melodies.
function hashToFreq(packId) {
  let hash = 0;
  for (let i = 0; i < packId.length; i += 1) {
    hash = (hash * 31 + packId.charCodeAt(i)) >>> 0;
  }
  const semitoneOffset = hash % 12;
  const baseFreq = 220; // A3
  return baseFreq * 2 ** (semitoneOffset / 12);
}

function synthesizePreview(pack) {
  const durationSeconds = 2.4;
  const totalSamples = Math.floor(SAMPLE_RATE * durationSeconds);
  const pcm = new Float32Array(totalSamples);
  const waveform = pickWaveform(pack);
  const rootFreq = hashToFreq(pack.packId);
  const arpRatios = [1, 1.25, 1.5, 2]; // simple major-ish arpeggio
  const noteSeconds = durationSeconds / (arpRatios.length * 2);
  const seedRef = { value: (rootFreq * 1000) >>> 0 || 1 };

  for (let i = 0; i < totalSamples; i += 1) {
    const t = i / SAMPLE_RATE;
    const noteIndex = Math.floor(t / noteSeconds) % arpRatios.length;
    const freq = rootFreq * arpRatios[noteIndex];

    let sample;
    if (waveform === "noise") {
      sample = noise(seedRef) * 0.6;
    } else {
      sample = waveform(t, freq) * 0.5;
    }

    // Simple per-note envelope so each arpeggio step doesn't click.
    const noteT = t % noteSeconds;
    const attack = Math.min(1, noteT / 0.01);
    const release = Math.min(1, (noteSeconds - noteT) / 0.02);
    const envelope = Math.min(attack, release);

    pcm[i] = sample * envelope;
  }

  return pcm;
}

function floatTo16BitPCM(float32) {
  const buffer = Buffer.alloc(float32.length * 2);
  for (let i = 0; i < float32.length; i += 1) {
    const clamped = Math.max(-1, Math.min(1, float32[i]));
    buffer.writeInt16LE(Math.round(clamped * 32767), i * 2);
  }
  return buffer;
}

function writeWavFile(filePath, pcm16, sampleRate) {
  const dataSize = pcm16.length;
  const header = Buffer.alloc(44);
  header.write("RIFF", 0);
  header.writeUInt32LE(36 + dataSize, 4);
  header.write("WAVE", 8);
  header.write("fmt ", 12);
  header.writeUInt32LE(16, 16);
  header.writeUInt16LE(1, 20); // PCM
  header.writeUInt16LE(1, 22); // mono
  header.writeUInt32LE(sampleRate, 24);
  header.writeUInt32LE(sampleRate * 2, 28);
  header.writeUInt16LE(2, 32);
  header.writeUInt16LE(16, 34);
  header.write("data", 36);
  header.writeUInt32LE(dataSize, 40);
  fs.writeFileSync(filePath, Buffer.concat([header, pcm16]));
}

for (const pack of DLC_CATALOG) {
  const pcmFloat = synthesizePreview(pack);
  const pcm16 = floatTo16BitPCM(pcmFloat);
  const outPath = path.join(OUT_DIR, `${pack.packId}.wav`);
  writeWavFile(outPath, pcm16, SAMPLE_RATE);
  console.log(`Wrote ${path.relative(process.cwd(), outPath)}`);
}

console.log(`\nGenerated ${DLC_CATALOG.length} original preview WAVs in public/dlc-previews/.`);
