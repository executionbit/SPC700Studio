class SpcPcmOutputProcessor extends AudioWorkletProcessor {
  constructor() {
    super();

    this.queue = [];
    this.offset = 0;
    this.recording = false;
    this.recordedFrames = [];

    this.port.onmessage = ({ data }) => {
      switch (data?.type) {
        case 'enqueue':
          if (data.frames) {
            this.queue.push(data.frames);
          }
          break;

        case 'start-recording':
          this.recording = true;
          this.recordedFrames = [];
          break;

        case 'stop-recording':
          this.recording = false;
          this.port.postMessage({
            type: 'recording-stopped',
            recordedFrames: this.recordedFrames
          });
          break;
      }
    };
  }

  process(_inputs, outputs) {
    const output = outputs[0];
    const left = output[0];
    const right = output[1] || left;

    for (let frame = 0; frame < left.length; frame += 1) {
      const queued = this.queue[0];

      if (!queued || this.offset + 1 >= queued.length) {
        if (queued && this.offset + 1 >= queued.length) {
          this.queue.shift();
          this.offset = 0;
        }

        left[frame] = 0;
        right[frame] = 0;
        continue;
      }

      const l = queued[this.offset];
      const r = queued[this.offset + 1];

      left[frame] = l;
      right[frame] = r;

      if (this.recording) {
        this.recordedFrames.push(l, r);
      }

      this.offset += 2;
    }

    return true;
  }
}

registerProcessor('spc-pcm-output', SpcPcmOutputProcessor);