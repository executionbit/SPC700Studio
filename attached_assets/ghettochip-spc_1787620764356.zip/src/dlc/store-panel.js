import { DLC_CATALOG } from "./catalog.js";
import { startDlcCheckout } from "./checkout.js";
import { EntitlementStore } from "./entitlements.js";

const API_BASE_URL = import.meta.env.VITE_DLC_API_BASE_URL ?? "";

/**
 * Renders the DLC store panel into `container` and wires up purchase
 * buttons, an existing-session confirmation flow, and entitlement badges.
 * Returns the EntitlementStore instance so callers (e.g. the sample
 * browser) can check `isUnlocked(packId)` before letting a user drag a
 * paid sample onto a voice.
 */
export async function mountDlcStorePanel(container) {
  const entitlements = new EntitlementStore({ apiBaseUrl: API_BASE_URL });

  container.innerHTML = `
    <div class="dlc-status" id="dlc-status" role="status"></div>
    <div class="dlc-grid" id="dlc-grid"></div>
  `;

  const grid = container.querySelector("#dlc-grid");
  const statusEl = container.querySelector("#dlc-status");

  const params = new URLSearchParams(window.location.search);
  if (params.get("checkout") === "success" && params.get("session_id")) {
    statusEl.textContent = "Confirming your purchase…";
    try {
      const { packIds } = await entitlements.completeCheckout(params.get("session_id"));
      statusEl.textContent = packIds.length
        ? `Unlocked: ${packIds.join(", ")}`
        : "Purchase confirmed.";
    } catch (error) {
      console.error(error);
      statusEl.textContent = `Could not confirm purchase automatically: ${error.message}`;
    }
    params.delete("checkout");
    params.delete("session_id");
    window.history.replaceState({}, "", `${window.location.pathname}`);
  } else if (params.get("checkout") === "cancelled") {
    statusEl.textContent = "Checkout cancelled — no charge was made.";
    params.delete("checkout");
    window.history.replaceState({}, "", `${window.location.pathname}`);
  } else {
    await entitlements
      .refreshFromServer(entitlements.getStoredCustomerToken())
      .catch(() => {});
  }

  const render = () => {
    grid.innerHTML = "";
    for (const pack of DLC_CATALOG) {
      const unlocked = entitlements.isUnlocked(pack.packId);
      const card = document.createElement("article");
      card.className = "dlc-card" + (unlocked ? " dlc-card--owned" : "");
      card.innerHTML = `
        <h3>${pack.name}</h3>
        <p class="dlc-desc">${pack.description}</p>
        <p class="dlc-meta">${pack.sampleCount} samples · ${pack.tags.join(", ")}</p>
        <audio class="dlc-preview" controls preload="none" src="/dlc-previews/${pack.packId}.wav"></audio>
        <div class="dlc-buy-row">
          <span class="dlc-price">${unlocked ? "OWNED" : `$${pack.priceUSD.toFixed(2)}`}</span>
          <button data-pack-id="${pack.packId}" ${unlocked ? "disabled" : ""}>
            ${unlocked ? "Unlocked" : "Buy"}
          </button>
        </div>
      `;
      grid.append(card);
    }
  };

  render();

  grid.addEventListener("click", async (event) => {
    const button = event.target.closest("button[data-pack-id]");
    if (!button || button.disabled) return;

    button.disabled = true;
    button.textContent = "Redirecting…";

    try {
      await startDlcCheckout({
        apiBaseUrl: API_BASE_URL,
        packIds: [button.dataset.packId]
      });
    } catch (error) {
      console.error(error);
      statusEl.textContent = `Checkout failed: ${error.message}`;
      button.disabled = false;
      button.textContent = "Buy";
    }
  });

  return entitlements;
}
