/**
 * Kicks off a Stripe Checkout purchase for one or more DLC packs.
 *
 * This never touches a Stripe secret key in the browser — it asks the
 * backend (server/index.js) to create the Checkout Session server-side,
 * then redirects the browser to the returned session URL. See
 * server/README.md for backend setup.
 */
export async function startDlcCheckout({ apiBaseUrl = "", packIds, email }) {
  if (!Array.isArray(packIds) || packIds.length === 0) {
    throw new Error("startDlcCheckout requires at least one packId.");
  }

  const response = await fetch(`${apiBaseUrl}/api/create-checkout-session`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      packIds,
      email,
      successUrl: `${window.location.origin}${window.location.pathname}?checkout=success&session_id={CHECKOUT_SESSION_ID}`,
      cancelUrl: `${window.location.origin}${window.location.pathname}?checkout=cancelled`
    })
  });

  if (!response.ok) {
    const body = await response.json().catch(() => ({}));
    throw new Error(body.error ?? `Checkout session request failed: ${response.status}`);
  }

  const { url } = await response.json();
  window.location.assign(url);
}
