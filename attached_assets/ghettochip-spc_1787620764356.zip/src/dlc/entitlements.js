/**
 * Tracks which DLC packs the current browser is entitled to.
 *
 * Entitlement is never trusted from localStorage alone — it is a cache of
 * what the backend last confirmed. The source of truth is always the
 * `/api/entitlements` endpoint on the server, which reads Stripe payment
 * records (see server/index.js).
 */
const STORAGE_KEY = "ghettochip.entitlements.v1";

export class EntitlementStore {
  constructor({ apiBaseUrl } = {}) {
    this.apiBaseUrl = apiBaseUrl ?? "";
    this.unlockedPackIds = new Set(this._readCache());
  }

  _readCache() {
    try {
      const raw = localStorage.getItem(STORAGE_KEY);
      return raw ? JSON.parse(raw) : [];
    } catch {
      return [];
    }
  }

  _writeCache() {
    try {
      localStorage.setItem(
        STORAGE_KEY,
        JSON.stringify([...this.unlockedPackIds])
      );
    } catch {
      // Storage unavailable (private mode, quota) — entitlement re-syncs
      // from the server on next refreshFromServer() call.
    }
  }

  isUnlocked(packId) {
    return this.unlockedPackIds.has(packId);
  }

  /**
   * Ask the backend which packs this customer has actually paid for.
   * `customerToken` is the opaque token issued by the backend after a
   * successful checkout (see completeCheckout below); pass null to check
   * only free/previously-cached entitlements.
   */
  async refreshFromServer(customerToken) {
    if (!customerToken) return [...this.unlockedPackIds];

    const response = await fetch(`${this.apiBaseUrl}/api/entitlements`, {
      headers: { Authorization: `Bearer ${customerToken}` }
    });

    if (!response.ok) {
      throw new Error(`Entitlement lookup failed: ${response.status}`);
    }

    const { packIds } = await response.json();
    this.unlockedPackIds = new Set(packIds);
    this._writeCache();
    return [...this.unlockedPackIds];
  }

  /**
   * Call after redirecting back from Stripe Checkout with ?session_id=...
   * Exchanges the Checkout Session for a customer token and the list of
   * packs that session paid for, then caches both.
   */
  async completeCheckout(sessionId) {
    const response = await fetch(`${this.apiBaseUrl}/api/checkout-session/${sessionId}`);

    if (!response.ok) {
      throw new Error(`Could not confirm checkout session: ${response.status}`);
    }

    const { customerToken, packIds } = await response.json();
    packIds.forEach((packId) => this.unlockedPackIds.add(packId));
    this._writeCache();

    if (customerToken) {
      localStorage.setItem("ghettochip.customerToken", customerToken);
    }

    return { customerToken, packIds };
  }

  getStoredCustomerToken() {
    return localStorage.getItem("ghettochip.customerToken");
  }
}
