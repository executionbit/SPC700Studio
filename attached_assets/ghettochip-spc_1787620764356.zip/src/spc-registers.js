export const DSP = Object.freeze({
  MVOLL: 0x0c,
  MVOLR: 0x1c,
  KON: 0x4c,
  KOF: 0x5c,
  FLG: 0x6c,
  NON: 0x3d,
  EON: 0x4d,

  voice(index) {
    if (!Number.isInteger(index) || index < 0 || index > 7) {
      throw new RangeError("S-DSP voice index must be 0 through 7.");
    }

    const base = index * 0x10;

    return Object.freeze({
      VOLL: base + 0x00,
      VOLR: base + 0x01,
      PITCHL: base + 0x02,
      PITCHH: base + 0x03,
      SRCN: base + 0x04,
      ADSR1: base + 0x05,
      ADSR2: base + 0x06,
      GAIN: base + 0x07
    });
  }
});
