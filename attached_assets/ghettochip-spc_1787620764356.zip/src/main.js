let audioContext = null;
let processor = null;
let isRecording = false;

async function initAudioWorklet() {
  if (audioContext && processor) {
    return { audioContext, processor };
  }

  const AudioContextClass = window.AudioContext || window.webkitAudioContext;
  audioContext = new AudioContextClass();

  await audioContext.audioWorklet.addModule('./spc-audio-worklet.js');

  processor = new AudioWorkletNode(audioContext, 'spc-pcm-output', {
    numberOfInputs: 0,
    numberOfOutputs: 1,
    outputChannelCount: [2]
  });

  processor.connect(audioContext.destination);

  processor.port.onmessage = ({ data }) => {
    if (data?.type === 'recording-stopped') {
      console.log('Recording stopped:', data.recordedFrames);
    } else {
      console.log('Received data:', data);
    }
  };

  return { audioContext, processor };
}

async function startRecording() {
  const { audioContext, processor } = await initAudioWorklet();

  if (audioContext.state === 'suspended') {
    await audioContext.resume();
  }

  processor.port.postMessage({ type: 'start-recording' });
  isRecording = true;
  console.log('Recording started');
}

async function stopRecording() {
  const { processor } = await initAudioWorklet();
  processor.port.postMessage({ type: 'stop-recording' });
  isRecording = false;
}

function addPcmFrame(frame) {
  if (processor) {
    processor.port.postMessage({ type: 'enqueue', frames: frame });
  }
}

const channelRack = document.getElementById('channel-rack');

function addChannel() {
  const channel = document.createElement('div');
  channel.className = 'channel';
  channel.innerHTML = `
    <strong>Channel</strong>
    <span>Effect: None</span>
  `;
  channelRack.appendChild(channel);
}

const recordButton = document.getElementById('record-button');
recordButton.addEventListener('click', async () => {
  if (!isRecording) {
    await startRecording();
    recordButton.textContent = 'Stop';
  } else {
    await stopRecording();
    recordButton.textContent = 'Record';
  }
});

document.getElementById('add-channel-button').addEventListener('click', addChannel);

let currentUser = null;
let currentWorkspace = null;

async function login(username) {
  currentUser = username;
  console.log(`User ${currentUser} logged in`);
}

async function createWorkspace(name) {
  currentWorkspace = name;
  console.log(`Workspace ${currentWorkspace} created`);
}

async function joinWorkspace(name) {
  currentWorkspace = name;
  console.log(`User ${currentUser} joined workspace ${currentWorkspace}`);
}

document.getElementById('login-button').addEventListener('click', () => {
  const username = document.getElementById('username-input').value;
  login(username);
});

document.getElementById('create-workspace-button').addEventListener('click', () => {
  const workspaceName = document.getElementById('workspace-name-input').value;
  createWorkspace(workspaceName);
});

document.getElementById('join-workspace-button').addEventListener('click', () => {
  const workspaceName = document.getElementById('workspace-name-input').value;
  joinWorkspace(workspaceName);
});

const chatInput = document.getElementById('chat-input');
const chatSend = document.getElementById('chat-send');
const chatMessages = document.getElementById('chat-messages');

chatSend.addEventListener('click', () => {
  const message = chatInput.value.trim();
  if (message) {
    addChatMessage(message);
    chatInput.value = '';
  }
});

function addChatMessage(message) {
  const messageElement = document.createElement('div');
  messageElement.textContent = message;
  chatMessages.appendChild(messageElement);
  chatMessages.scrollTop = chatMessages.scrollHeight;
}