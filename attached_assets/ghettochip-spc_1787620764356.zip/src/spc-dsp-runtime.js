export class SpcDspRuntime {
  constructor() {
    this.module = null;
    this.instance = 0;
  }

  async initialize() {
    if (this.instance) return;

    // Vite copies public/ content to the deployment root.
    const base = import.meta.env.BASE_URL;
    const factoryModule = await import(/* @vite-ignore */ `${base}wasm/spc-dsp.js`);
    const createModule = factoryModule.default;

    if (typeof createModule !== "function") {
      throw new Error("spc-dsp.js does not export an Emscripten module factory.");
    }

    this.module = await createModule({
      locateFile: (path) => `${base}wasm/${path}`
    });

    this.instance = this.module._spc_dsp_create();

    if (!this.instance) {
      throw new Error("The S-DSP WebAssembly core could not create an instance.");
    }
  }

  writeDsp(address, value) {
    this.assertInitialized();
    this.module._spc_dsp_write(this.instance, address & 0x7f, value & 0xff);
  }

  readDsp(address) {
    this.assertInitialized();
    return this.module._spc_dsp_read(this.instance, address & 0x7f) & 0xff;
  }

  getRamPointer() {
    this.assertInitialized();
    return this.module._spc_dsp_ram(this.instance);
  }

  dispose() {
    if (this.module && this.instance) {
      this.module._spc_dsp_destroy(this.instance);
    }

    this.instance = 0;
    this.module = null;
  }

  assertInitialized() {
    if (!this.module || !this.instance) {
      throw new Error("S-DSP runtime has not been initialized.");
    }
  }
}
