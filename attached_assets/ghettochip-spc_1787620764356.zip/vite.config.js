import { defineConfig } from "vite";

export default defineConfig({
  // Portable for GitHub Pages project paths and normal static hosting.
  base: "./",
  build: {
    target: "es2022",
    outDir: "dist",
    sourcemap: true,
    emptyOutDir: true
  }
});
