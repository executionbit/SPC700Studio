# Ghettochip Studio — SPC700 Workstation

Browser workstation scaffold for an emulated SNES S-DSP backend powered by
`snes-spc-arm` compiled to WebAssembly.

## Status

The repository currently supplies:

- Vite static-app configuration
- Initial 8-voice workstation shell
- C ABI wrapper for standalone `SPC_DSP`
- Emscripten build script
- WASM loading adapter
- AudioWorklet output queue scaffold
- GitHub Pages deployment workflow

Still required for a functional SPC DAW:

- BRR sample import/encoding and APU-RAM sample-directory placement
- Real-time WASM PCM render scheduling
- PCM queue producer with underrun protection
- Sequencer-to-voice register mapping
- ADSR/GAIN and global DSP register UI
- Echo/FIR controls
- Offline render/export validation

## Prerequisites

- Node.js 22+
- npm
- Emscripten SDK with `em++` on `PATH`
- A pinned checkout of `snes-spc-arm` at `vendor/snes-spc-arm`

## Setup

```bash
git submodule add https://github.com/nathancassano/snes-spc-arm.git vendor/snes-spc-arm
npm install
```

## Local development

```bash
npm run dev
```

## Production build

```bash
source ~/emsdk/emsdk_env.sh
npm run build
npm run preview
```

## GitHub Pages

Push to `main`. The included workflow builds WASM and deploys `dist/`.

If needed, open **Settings → Pages → Build and deployment** and select
**GitHub Actions**.

## Licensing and assets

`snes-spc-arm` / `snes_spc` is LGPL-licensed. Before publishing, retain the
complete license text, upstream notices, exact source revision, corresponding
source/build instructions, and modification history. Do not ship commercial
video-game assets, BRR dumps, samples, logos, or music without permission.
