# Third-party notices

## snes-spc-arm / snes_spc

This project is intended to build against:

- Upstream: <https://github.com/nathancassano/snes-spc-arm>
- Component: standalone `SPC_DSP`
- License: GNU Lesser General Public License (LGPL)
- Integration: separately compiled WebAssembly module

Before production release:

1. Pin the dependency to an exact commit or release.
2. Include the complete, verbatim license text.
3. Preserve every upstream copyright/license notice.
4. Provide corresponding source plus instructions to rebuild the exact WASM module.
5. Document modifications made to dependency files.
6. Ensure the deployed project does not contain unlicensed game samples, BRR dumps, music, artwork, or logos.
